/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  Alert
} from 'react-native';

export default class hello extends Component {
  render() {
    const img = require('./ghifari.jpg')
    const changeMe = () => {
      Alert.alert('Button has been pressed!')
    }
    return (
      <View style={styles.container}>
        <Image source={img} style={styles.img}/>
        <Text style={styles.name}>
          {profile.name}
        </Text>
        <Button onPress={changeMe} style={styles.instructions} title={profile.refactory} />


      </View>
    );
  }
}

const profile = {
  name: 'Sutani',
  refactory: 'Refactory Batch-1'
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#7bbfea',
  },
  img: {
    width: 120,
    height: 160,
    borderRadius: 5,
  },
  name: {
    fontSize: 30,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
AppRegistry.registerComponent('hello', () => hello);
